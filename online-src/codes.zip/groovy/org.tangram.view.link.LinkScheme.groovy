package maven.repository.links;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.tangram.Constants;
import org.tangram.content.Content;
import org.tangram.content.BeanFactory;
import org.tangram.controller.DefaultController;
import org.tangram.view.Utils;
import org.tangram.view.TargetDescriptor;
import org.tangram.view.link.Link;
import org.tangram.view.link.LinkScheme;

import org.tangram.gae.protection.GoogleProtection;
import org.tangram.gae.protection.OpenIDProtection;

import maven.repository.content.Artifact;

public class DefaultLinkScheme implements LinkScheme {
  
  private static Log log = LogFactory.getLog(DefaultLinkScheme.class);

  private BeanFactory beanFactory;
  
  
  public void setBeanFactory(BeanFactory factory) {
      beanFactory = factory;
  } // setBeanFactory()
  
  
  public void setDefaultController(DefaultController defaultController) {
      // Automagically set default view
      defaultController.getCustomLinkViews().add(Constants.DEFAULT_VIEW)
      defaultController.getCustomLinkViews().add("pom")
      defaultController.getCustomLinkViews().add("sources")
      defaultController.getCustomLinkViews().add("war")
      defaultController.getCustomLinkViews().add("zip")
  } // setDefaultController ()
  
  
  public Link createLink(HttpServletRequest request, HttpServletResponse response, Object bean, String action, String view) {    
      Link result = null
      if (action==null) {
          if (bean instanceof Artifact) {
              String groupId = "-"
              String artifactId = "-"
              String version = "0"
              String extension = ""
              String addonClassifier = ""
              Artifact a = (Artifact)bean;
              try {
                  groupId = Utils.urlize(a.groupId)
                  artifactId = Utils.urlize(a.artifactId)
                  version = Utils.urlize(a.version)
                  extension = "."+Utils.urlize(a.packaging)
                  addonClassifier = Utils.urlize(a.addonClassifier)
              } catch (UnsupportedEncodingException uee) {
                  log.error("createLink()", uee);
              } // try
              if ("pom".equals(view)) {
                extension = "."+view
              } // if
              if ("sources".equals(view)) {
                extension = "-sources"+extension
              } // if
              if (addonClassifier.equals(view)) {
                extension = "-"+view+"."+view
              } // if
              String url = "/"+groupId+"/"+artifactId+"/"+version+"/"+artifactId+"-"+version+extension
              result = new Link()
              result.setUrl(url)
          } // if
      } // if
      return result
  } // createLink()

  
  public TargetDescriptor parseLink(String url, HttpServletResponse response) {
      TargetDescriptor result = null
      if (url.equals("/")) {
          try {
              List<Artifact> artifacts = beanFactory.listBeans(Artifact.class, null)
              result = new TargetDescriptor(artifacts, null, null)
          } catch (Exception e) {
              result = new TargetDescriptor(e, null, null)
          } // try/catch
      } else if (url.equals("/login")) {
          try {
              List<Artifact> beans = beanFactory.listBeans(OpenIDProtection.class, null)
              result = new TargetDescriptor(beans.get(0), 'login', null)
          } catch (Exception e) {
              result = new TargetDescriptor(e, null, null)
          } // try/catch
      } else if (url.equals("/googlelogin")) {
          try {
              List<Artifact> beans = beanFactory.listBeans(GoogleProtection.class, null)
              result = new TargetDescriptor(beans.get(0), 'login', null)
          } catch (Exception e) {
              result = new TargetDescriptor(e, null, null)
          } // try/catch
      } else {
          Object bean  = null
          try {
              String[] elements = url.split("/")
              String groupId = elements[1]
              String artifactId = elements[2]
              String version = elements[3]
              String name = elements[4]
           
              List<Artifact> artifacts = beanFactory.listBeans(Artifact.class, "groupId=='"+groupId+"' && artifactId=='"+artifactId+"'"+" && version=='"+version+"'")
              if (artifacts.size() > 0) {
                  Artifact a = artifacts.get(0)
                  if (name.endsWith(".pom")) {
                      bean = a.pom
                  } // if
                  if (name.endsWith(".pom.sha1")) {
                      bean = a.pomSha1
                  } // if
                  if (name.endsWith(".pom.md5")) {
                      bean = a.pomMd5
                  } // if
                  if (bean == null) {
                      if (log.isInfoEnabled()) {
                          log.info("parseLink() name="+name+" packaging="+a.packaging)
                      } // if
                      String packaging = "."+a.packaging
                      String addonClassifier = a.getAddonClassifier()
                      if (name.indexOf("-sources.") > 0) {
                          if (name.endsWith(".sha1")) {
                              bean = a.sourcesSha1
                          } // if
                          if (name.endsWith(".md5")) {
                              bean = a.sourcesMd5
                          } // if
                          if (name.endsWith(packaging)) {
                              bean = artifacts.get(0).sources
                          } // if
                      } else {
                          if (name.indexOf("-"+addonClassifier+".") > 0) {
                              if (name.endsWith(".sha1")) {
                                  bean = a.addonSha1
                              } // if
                              if (name.endsWith(".md5")) {
                                  bean = a.addonMd5
                              } // if
                              if (name.endsWith("."+addonClassifier)) {
                                  bean = artifacts.get(0).addon
                              } // if
                          } else {
                              if (name.endsWith(packaging+".sha1")) {
                                  bean = a.dataSha1
                              } // if
                              if (name.endsWith(packaging+".md5")) {
                                  bean = a.dataMd5
                              } // if
                              if (name.endsWith(a.artifactId+"-"+a.version+packaging)) {
                                  bean = artifacts.get(0).data
                              } // if
                          } // if
                      } // if
                  } // if
              } // if
          } catch (Exception e) {
              bean = null;
              if (log.isWarnEnabled()) {
                  log.warn("parseLink() exception", e)
              } // if
          } // try/catch
          
          if (bean != null) {
              result = new TargetDescriptor(bean, null, null)
          } else {
              if (log.isWarnEnabled()) {
                  log.warn("parseLink() nothing mapped returning 404 for "+url)
              } // if
          } // if
      } // if
      return result
  } // parseLink()
    
} // DefaultLinkScheme
    