package maven.repository.links;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.tangram.Constants;
import org.tangram.content.Content;
import org.tangram.content.BeanFactory;
import org.tangram.controller.DefaultController;
import org.tangram.view.Utils;
import org.tangram.view.TargetDescriptor;
import org.tangram.view.link.Link;
import org.tangram.view.link.LinkScheme;

import org.tangram.gae.protection.GoogleProtection;
import org.tangram.gae.protection.OpenIDProtection;

import maven.repository.content.Artifact;

public class DefaultLinkScheme implements LinkScheme {
  
  private static Log log = LogFactory.getLog(DefaultLinkScheme.class);

  private BeanFactory beanFactory;
  
  
  public void setBeanFactory(BeanFactory factory) {
      beanFactory = factory;
  } // setBeanFactory()
  
  
  public void setDefaultController(DefaultController defaultController) {
      // Automagically set default view
      defaultController.getCustomLinkViews().add(Constants.DEFAULT_VIEW);
  } // setDefaultController ()
  
  
  public Link createLink(HttpServletRequest request, HttpServletResponse response, Object bean, String action, String view) {    
      Link result = null;
      if (action==null) {
          if (bean instanceof Artifact) {
              String groupId = "-";
              String artifactId = "-";
              String version = "0";
              String extension = "";
              Artifact a = (Artifact)bean;
              try {
                  groupId = Utils.urlize(a.getGroupId());
                  artifactId = Utils.urlize(a.getArtifactId());
                  version = Utils.urlize(a.getVersion());
                  extension = "."+Utils.urlize(a.getPackaging());
              } catch (UnsupportedEncodingException uee) {
                  log.error("createLink()", uee);
              } // try
              if (view != null) {
                extension = "."+view;
              } // if                
              String url = "/"+groupId+"/"+artifactId+"/"+version+"/"+artifactId+"-"+version+extension;
              result = new Link();
              result.setUrl(url);
          } // if
      } // if
      return result;    
  } // createLink()

  
  public TargetDescriptor parseLink(String url, HttpServletResponse response) {
      TargetDescriptor result = null;
      if (url.equals("/")) {
          try {
              List<Artifact> artifacts = beanFactory.listBeans(Artifact.class, null);
              result = new TargetDescriptor(artifacts, null, null);
          } catch (Exception e) {
              result = new TargetDescriptor(e, null, null);
          } // try/catch
      } else if (url.equals("/login")) {
          try {
              List<Artifact> beans = beanFactory.listBeans(OpenIDProtection.class, null);
              result = new TargetDescriptor(beans.get(0), 'login', null);
          } catch (Exception e) {
              result = new TargetDescriptor(e, null, null);
          } // try/catch
      } else if (url.equals("/googlelogin")) {
          try {
              List<Artifact> beans = beanFactory.listBeans(GoogleProtection.class, null);
              result = new TargetDescriptor(beans.get(0), 'login', null);
          } catch (Exception e) {
              result = new TargetDescriptor(e, null, null);
          } // try/catch
      } else {
          String id = null;
          Object bean  = null;
          String[] elements = url.split("/");
          String groupId = elements[1];
          String artifactId = elements[2];
          String version = elements[3];
          String name = elements[4];
          
          List<Artifact> artifacts = 
            beanFactory.listBeans(Artifact.class, "groupId=='"+groupId
                                         +"' && artifactId=='"+artifactId+"'"
                                            +" && version=='"+version+"'");
          if (artifacts.size() > 0) {
             Artifact a = artifacts.get(0);
             if (name.endsWith(".pom")) {
                 bean = a.getPom();
             } // if
             if (name.endsWith(".pom.sha1")) {
                 bean = a.getPomSha1();
             } // if
             if (name.endsWith(".pom.md5")) {
                 bean = a.getPomMd5();
             } // if
             if (bean == null) {
                 if (name.endsWith(".sha1")) {
                     bean = a.getDataSha1();
                 } // if
                 if (name.endsWith(".md5")) {
                     bean = a.getDataMd5();
                 } // if
                 if (bean == null) {
                   bean = artifacts.get(0).getData();
                 } // if
             } // if
          } // if
          
          if (bean != null) {
              result = new TargetDescriptor(bean, null, null);
          } else {
              if (log.isWarnEnabled()) {
                  log.warn("parseLink() returning 404 for "+url);
              } // if
          } // if
      } // if
      return result;
  } // parseLink()
    
} // DefaultLinkScheme 
    
